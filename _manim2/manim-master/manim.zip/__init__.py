#!/usr/bin/env python

import manim.config
import manim.constants
import manim.extract_scene
import manim.stream_starter


def main():
    args = manim.config.parse_cli()
    if not args.livestream:
        config = manim.config.get_configuration(args)
        manim.constants.initialize_directories(config)
        manim.extract_scene.main(config)
    else:
        manim.stream_starter.start_livestream(
            to_twitch=args.to_twitch,
            twitch_key=args.twitch_key,
        )
